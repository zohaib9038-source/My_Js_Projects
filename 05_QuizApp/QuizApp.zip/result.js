let content=document.querySelector('.content');
console.log(content);
// localStorage.getItem('score'));
console.log(quizData);
content.style.width=`${(localStorage.getItem('score')/quizData.length)*100}%`;
let correctOutOfTotal=document.querySelector('.correctOutOfTotal h2');
if(localStorage.getItem('score')){
correctOutOfTotal.innerText=localStorage.getItem('score')+'/'+quizData.length;
}else{
    correctOutOfTotal.innerText=0+'/'+quizData.length;
}
